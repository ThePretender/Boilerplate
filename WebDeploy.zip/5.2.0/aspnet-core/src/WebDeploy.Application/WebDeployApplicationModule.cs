﻿using Abp.AutoMapper;
using Abp.Modules;
using Abp.Reflection.Extensions;
using WebDeploy.Authorization;

namespace WebDeploy
{
    [DependsOn(
        typeof(WebDeployCoreModule), 
        typeof(AbpAutoMapperModule))]
    public class WebDeployApplicationModule : AbpModule
    {
        public override void PreInitialize()
        {
            Configuration.Authorization.Providers.Add<WebDeployAuthorizationProvider>();
        }

        public override void Initialize()
        {
            var thisAssembly = typeof(WebDeployApplicationModule).GetAssembly();

            IocManager.RegisterAssemblyByConvention(thisAssembly);

            Configuration.Modules.AbpAutoMapper().Configurators.Add(
                // Scan the assembly for classes which inherit from AutoMapper.Profile
                cfg => cfg.AddMaps(thisAssembly)
            );
        }
    }
}
