﻿using System.Threading.Tasks;
using WebDeploy.Configuration.Dto;

namespace WebDeploy.Configuration
{
    public interface IConfigurationAppService
    {
        Task ChangeUiTheme(ChangeUiThemeInput input);
    }
}
