﻿using WebDeploy.Configuration.Ui;

namespace WebDeploy.Web.Views.Shared.Components.RightSideBar
{
    public class RightSideBarViewModel
    {
        public UiThemeInfo CurrentTheme { get; set; }
    }
}
