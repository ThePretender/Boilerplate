using System.ComponentModel.DataAnnotations;

namespace WebDeploy.Users.Dto
{
    public class ChangeUserLanguageDto
    {
        [Required]
        public string LanguageName { get; set; }
    }
}