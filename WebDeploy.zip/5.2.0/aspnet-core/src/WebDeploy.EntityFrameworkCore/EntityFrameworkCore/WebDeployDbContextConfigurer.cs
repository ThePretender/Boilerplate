using System.Data.Common;
using Microsoft.EntityFrameworkCore;

namespace WebDeploy.EntityFrameworkCore
{
    public static class WebDeployDbContextConfigurer
    {
        public static void Configure(DbContextOptionsBuilder<WebDeployDbContext> builder, string connectionString)
        {
            builder.UseSqlServer(connectionString);
        }

        public static void Configure(DbContextOptionsBuilder<WebDeployDbContext> builder, DbConnection connection)
        {
            builder.UseSqlServer(connection);
        }
    }
}
