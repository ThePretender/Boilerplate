﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Abp.Modules;
using Abp.Reflection.Extensions;
using WebDeploy.Configuration;

namespace WebDeploy.Web.Host.Startup
{
    [DependsOn(
       typeof(WebDeployWebCoreModule))]
    public class WebDeployWebHostModule: AbpModule
    {
        private readonly IHostingEnvironment _env;
        private readonly IConfigurationRoot _appConfiguration;

        public WebDeployWebHostModule(IHostingEnvironment env)
        {
            _env = env;
            _appConfiguration = env.GetAppConfiguration();
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(WebDeployWebHostModule).GetAssembly());
        }
    }
}
