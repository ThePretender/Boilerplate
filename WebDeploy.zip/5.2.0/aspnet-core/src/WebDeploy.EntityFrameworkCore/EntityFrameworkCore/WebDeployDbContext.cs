﻿using Microsoft.EntityFrameworkCore;
using Abp.Zero.EntityFrameworkCore;
using WebDeploy.Authorization.Roles;
using WebDeploy.Authorization.Users;
using WebDeploy.MultiTenancy;

namespace WebDeploy.EntityFrameworkCore
{
    public class WebDeployDbContext : AbpZeroDbContext<Tenant, Role, User, WebDeployDbContext>
    {
        /* Define a DbSet for each entity of the application */
        
        public WebDeployDbContext(DbContextOptions<WebDeployDbContext> options)
            : base(options)
        {
        }
    }
}
