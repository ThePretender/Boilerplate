import { WebDeployTemplatePage } from './app.po';

describe('WebDeploy App', function() {
  let page: WebDeployTemplatePage;

  beforeEach(() => {
    page = new WebDeployTemplatePage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
