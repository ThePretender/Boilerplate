﻿using System.Threading.Tasks;
using Abp.Authorization;
using Abp.Runtime.Session;
using WebDeploy.Configuration.Dto;

namespace WebDeploy.Configuration
{
    [AbpAuthorize]
    public class ConfigurationAppService : WebDeployAppServiceBase, IConfigurationAppService
    {
        public async Task ChangeUiTheme(ChangeUiThemeInput input)
        {
            await SettingManager.ChangeSettingForUserAsync(AbpSession.ToUserIdentifier(), AppSettingNames.UiTheme, input.Theme);
        }
    }
}
