﻿using Abp.AspNetCore.Mvc.ViewComponents;

namespace WebDeploy.Web.Views
{
    public abstract class WebDeployViewComponent : AbpViewComponent
    {
        protected WebDeployViewComponent()
        {
            LocalizationSourceName = WebDeployConsts.LocalizationSourceName;
        }
    }
}
