﻿using Microsoft.AspNetCore.Mvc.Razor.Internal;
using Abp.AspNetCore.Mvc.Views;
using Abp.Runtime.Session;

namespace WebDeploy.Web.Views
{
    public abstract class WebDeployRazorPage<TModel> : AbpRazorPage<TModel>
    {
        [RazorInject]
        public IAbpSession AbpSession { get; set; }

        protected WebDeployRazorPage()
        {
            LocalizationSourceName = WebDeployConsts.LocalizationSourceName;
        }
    }
}
